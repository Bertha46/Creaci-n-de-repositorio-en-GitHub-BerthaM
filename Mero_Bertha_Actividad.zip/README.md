# Repositorio de Desarrollo de Aplicaciones Web
**Estudiante:** Bertha Mero  

Este repositorio contiene las prácticas y ejercicios desarrollados en la asignatura.

## Contenidos
1. Estructura HTML5
2. Formularios y validaciones
3. Estilos con CSS3 (Selectores y Caja)
4. Lógica interactiva con JavaScript

### Primer Commit
Este es el commit inicial que establece la base del proyecto.
