// Introducción a JavaScript - Ejercicio de Aplicación
function validarFormulario() {
    const nombre = document.getElementById('nombre').value;
    const email = document.getElementById('email').value;

    if (nombre === "" || email === "") {
        alert("Por favor, completa todos los campos.");
    } else {
        alert("¡Hola " + nombre + "! Tus datos han sido procesados correctamente.");
        console.log("Nombre: " + nombre + ", Email: " + email);
    }
}